declare module 'aws-sdk/clients/s3'
declare module 'aws-sdk'
